'''
	Demonstrates simple unit testing with the 
	Python Unit Test framework
	https://docs.python.org/3/library/unittest.html
'''
import unittest				# Pythons unit test module
import poker_functions		# the poker function module to test
import poker_hand_generator	# the random hand generator

class PokerTests(unittest.TestCase):
	# define a function for each test
	def test_flush_positive(self):
		# test 50 random flushes
		for i in range(50):
			hand = poker_hand_generator.generate_flush()	# get a random flush hand
			rank = poker_functions.flush(hand)				# pass it to the function you're testing
			self.assertEqual( rank, 5 )						# use assertion to test the result

	def test_flush_negative(self):
		# test to ensure the flush function doesn't incorrectly identify a non-flush hand
		for i in range(10):										# do 10 of each hand
			hand = poker_hand_generator.generate_full_house()	# full house
			rank = poker_functions.flush(hand)
			self.assertNotEqual( rank, 5 )						# use assert not equal
			hand = poker_hand_generator.generate_two_pair()		# two pair
			rank = poker_functions.flush(hand)
			self.assertNotEqual( rank, 5 )
			hand = poker_hand_generator.generate_N_of_a_kind(3)	# 3 of a kind
			rank = poker_functions.flush(hand)
			self.assertNotEqual( rank, 5 )
			hand = poker_hand_generator.generate_N_of_a_kind(4)	# 4 of a kind
			rank = poker_functions.flush(hand)
			self.assertNotEqual( rank, 5 )

if __name__ == '__main__':
	unittest.main()