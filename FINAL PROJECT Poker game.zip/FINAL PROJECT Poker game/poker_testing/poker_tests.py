'''
	Demonstrates simple testing with assertions
	This approach does not utilize Pythons unit test module
	"assert" is a useful keyword in Python: https://realpython.com/python-assert-statement/
'''
import poker_functions		# the poker function module to test
import poker_hand_generator	# the random hand generator

def test_flush_positive():
	# test 50 random flushes
	for i in range(50):
		hand = poker_hand_generator.generate_flush()	# get a random flush hand
		rank = poker_functions.flush(hand)				# pass it to the function you're testing
		
		# use assertion to test the result. 
		# True assertions will allow the program to continue
		# False assertions will halt program flow with an error message
		# you can also include a custom message as shown below
		assert rank == 5, 'rank should be 5'
  
def test_flush_negative():
	# test to ensure the flush function doesn't incorrectly identify a non-flush hand
	for i in range(10):										# do 10 of each hand
		hand = poker_hand_generator.generate_full_house()	# full house
		rank = poker_functions.flush(hand)
		assert rank != 5,'rank should be 6'					# use assert not equal
		hand = poker_hand_generator.generate_two_pair()		# two pair
		rank = poker_functions.flush(hand)
		assert rank != 5, 'rank should be 2'
		hand = poker_hand_generator.generate_N_of_a_kind(3)	# 3 of a kind
		rank = poker_functions.flush(hand)
		assert rank != 5, 'rank should be 3'
		hand = poker_hand_generator.generate_N_of_a_kind(4)	# 4 of a kind
		rank = poker_functions.flush(hand)
		assert rank != 5, 'rank should be 7'

def run_all_tests():
	test_flush_positive()
	test_flush_negative()
	print("All Tests Passed") # if you make it here all assertions passed

if __name__ == '__main__':
	run_all_tests()