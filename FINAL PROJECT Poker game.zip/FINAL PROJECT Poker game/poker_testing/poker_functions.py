def flush(hand: dict) -> int:
	'''
		Determines if a 5 card poker hand is a flush

		Parameters:
			hand (dict): The poker hand organized by suit

		Returns:
			int: 5 is the hand is a flush, 0 if it is not
   
		Examples/Doctests:
		>>> flush({0: [], 1: [(3, 1), (6, 1), (11, 1), (12, 1), (10, 1)], 2: [], 3: []})
		5
  
		>>> flush({0: [], 1: [], 2: [], 3: [(4, 3), (1, 3), (8, 3), (9, 3), (2, 3)]})
		5
  
		>>> flush({0: [(3, 0)], 1: [(10, 1)], 2: [], 3: [(4, 3), (1, 3), (8, 3)]})
		0
	'''
	for suit, cards in hand.items():	# iterate through the suits in hand
		if len(cards) == 5:				# does any suit list have 5 cards?
			return 5					# yes, return 5 (the rank)
	return 0							# made it all the way through the hand, there's no flush

