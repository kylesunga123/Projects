suits = {0: "Hearts", 1: "Diamonds", 2: "Clubs", 3: "Spades"}
ranks = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13)

from random import randint #task 1 q3

name_ranks = {
        1: "Ace",
        11: "Jack",
        12: "Queen",
        13: "King"
    }

def create_deck():
    deck = []                       #empty list. my deck of cards
    for suit in suits:              
        for rank in ranks:
            card = (rank, suit)     #tuple formatted ex. (king, hearts)
            deck.append(card)       #adding to the deck/list
    return deck 

def print_card(card: tuple) -> None:
    '''
	Accepts a single card prints the rank and suit of card

	Parameters:
		card (tuple): a tuple that represents a card
	Returns:
		rank and suit of the card
	Examples/Doctests:
	>>> print_card((11,0))
	"Jack of Hearts"
	'''
    suit = card[1]
    rank = card[0]
    suit_text = suits[suit]
    if rank in name_ranks:                              # if rank is in ranks
        print(f'{name_ranks[rank]} of {suit_text}')     #print name_ranks 1,11,12,13
    else:
        print(f' {rank} of {suit_text}')                #else print 2-10

def swap(deck: list, index1: int, index2: int) -> list:
    deck[index1], deck[index2] = deck[index2], deck[index1]
    
def shuffle(deck: list) -> None:
    for i in range(1000):
        index1 = randint(0, len(deck) - 1)
        index2 = randint(0, len(deck) - 1)
        swap(deck, index1, index2)

def deal(deck: list) -> tuple:
    '''
    deals card from deck by returning and removing top card. 
    length of deck must be reduced by 1 each time function is called. 
    '''
    top_card = deck.pop(0)
    return deck

#----------------TASK 2-------------------
'''
HAND RANKS
1. Straight Flush: All cards are the same suit and in order
2. Four of a Kind: Four Cards of the same rank
3. Full House: Three Cards of one rank and two of another rank 4. Flush: Five cards of the same suit but not in order
5. Straight: Five Cards in sequence but not the same suit
6. Three of a Kind: Three Cards of the same rank
7. Two Pair: A pair is two cards, same rank. Two of these
8. One Pair: Two cards of the same rank
9. No combination: Ranked by highest card
'''
def deal_hands(num_hands, deck):
    '''
    creates empty hand dictionary for each hand and fills them with
    five cards by alternating dealing a simgle card to each hand
    '''

    hands = []          # empty list for multiple hands
    for i in range(num_hands):

    
        hand = {
            0:[],
            1:[],
            2:[],
            3:[],
        }
        hands.append(hand)      # adding dictionary to list of empty hands

    for i in range(5):                  # one hand
        for j in range(num_hands):       #making multiple hands
            new_card = deal(deck) 
            if new_card[1] == 0:            
                hands[j][0].append(new_card)    #hand dict 0 adding new card to it
            elif new_card[1] == 1:
                hands[j][1].append(new_card)
            elif new_card[1] == 2:
                hands[j][1].append(new_card)
            elif new_card[1] == 3:
                hands[j][1].append(new_card)
            
    return hands

def print_hand(hand: dict):
    '''
    accepts a single hand and rpitns it to console by defining 
    a loop and calling your print card function
    '''
    for suit in hand.values():      #iterating through each key in the dictionary 'hand'
        for card in suit:           #iterate through each card in the suit
            print_card(card)        # calling print card fucntion and printing card

#-------------TASK 3-------------------
    
def straight_flush(hand: dict) -> int:
    '''
    takes a hand of cards. check to see if a single suit has 5 cards and if 
    they are in sequential order.

    Accepts:
    dict

    Returns:
    int

    Examples/Doctest:
    >>> straight_flush( {0: [(6, 0), (4,0), (5,0), (7,0), (3,0)] 1: [], 2:[], 3:[]} )
    8
    >>> straight_flush( {0: [(6,0), (4,0), (8,0), (12,0)], 1: [], 2: [(1,2)], 3: []})
    0
    '''
    for suit in hand.values():                 
        if len(suit) == 5:                      #lenth of suit is 5
            suit.sort()                         
            if suit[0][0] + 4 == suit[-1][0]:   #index ranks of first and last card
                return 8                        
    return 0                                    

def flush(hand: dict) -> int:          
    '''
    Determine if a poker hand has a flush.

    Examples/Doctest:
    >>> flush({'hearts': ['10', '2', '6', '4', '8'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3', 'A']})
    5
    >>> flush({'hearts': ['10', '2', '6', '4', '8'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3']})
    0
    >>> flush({'hearts': ['10', '2', '6', '4', '8', '7'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3', 'A']})
    0
    '''
    for suit in hand.values():          #Iterate through each suit in the hand
        if len(suit) == 5:              #Check if the length of the suit is 5, indicating a flushj
            return 5                    
    return 0                           

#--------------TASK 4---------------

def hand_ranks(hand: dict):
    '''
    Calculate the count of each card rank in a poker hand

    Returns:
    A list containing the count of each card rank in the hand

    Examples/Doctest:
    >>> hand_ranks({'hearts': ['10', '2', '6', '4', '8'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3', 'A']})
    [0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0]
    >>> hand_ranks({'hearts': ['10', '2', '6', '4', '8'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3']})
    [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0]
    >>> hand_ranks({'hearts': ['10', '2', '6', '4', '8', '7'], 'diamonds': ['5', 'K', '7'], 'clubs': ['Q', '9'], 'spades': ['3', 'A']})
    [0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0]
    '''
    rank_list = [0] * 13                    #Create list to store the count of each card rank
    for key in hand:
        cards_list = hand[key]              #Get the list associated with key
        for card in cards_list:            
            rank_list[card[0]-1] += 1       #Increment the count of the card's rank in the rank_list
    return rank_list
    
def four_of_a_kind(rank_list: list):
    '''
    Checks if there is a four-of-a-kind in a list of card ranks.

    Each index in the list represents a card rank (1-13).
    
    Examples/Doctest:
    >>>  four_of_a_kind([3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0])
    7
    >>> four_of_a_kind([0, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0])
    0
    '''
    for i in range(len(rank_list)):
        rank = rank_list[i]             
        if rank == 4:                   #check if count is 4
            return 7                    # yes return 7
    return 0                            # else 0

        
def full_house(rank_list: list): 
    '''
    Determine if a poker hand has a full house

    Parameters:
    A list containing the count of each card rank in a poker hand

    Returns:
    If a full house is present, return 6 otherwise return 0.

    Examples/Doctests:
    >>> full_house([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    6
    >>> full_house([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    0
    >>> full_house([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    6
    '''
    three_cards = False
    two_cards = False
    for i in range(len(rank_list)):
        rank = rank_list[i]
        if rank == 3:                                   #Check for 3 cards of the same rank
            three_cards = True
        if rank == 2:                                   #same thing but w/ 2
            two_cards = True
    if three_cards == True and two_cards == True:	    
        return 6
    else:
        return 0			
        

def straight(rank_list: list):
    """
    Determine if a poker hand has a straight.

    Parameters:
    A list containing the count of each card rank in a poker hand.

    Returns:
    If a straight is present, return 4; otherwise, return 0.

    Example:
    >>> straight([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    4
    >>> straight([0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0])
    0
    >>> straight([0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0])
    0
    """
    count = 0

    
    for i in range(len(rank_list)-1):
        if rank_list[i+1] != 0:                         # Check if the next rank has cards
            x = rank_list[i+1] - rank_list[i]           #Calculate the difference between the next rank and the current rank
            if x == 0:                                  # If the difference is 0, increment the count
                count += 1
    if count == 4:
        return 4
    else:
        return 0


def three_of_a_kind(rank_list: list):
    """
    Determine if a poker hand has three of a kind.

    Parameters:
    A list containing the count of each card rank in a poker hand.

    Returns:
    If three of a kind is present, return 3; otherwise, return 0.

    Examples/Doctest:
    >>> three_of_a_kind([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    3
    >>> three_of_a_kind([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    0
    >>> three_of_a_kind([0, 1, 1, 1, 2, 1, 0, 1, 1, 1, 0, 0, 0])
    3
    """
    three_cards = False
    for i in range(len(rank_list)):
        rank = rank_list[i]
        if rank == 3:                   
            three_cards = True
    if three_cards:
        return 3
    else:
        return 0

     
def two_pair(rank_list: list):
    """
    Determine if a poker hand has two pairs.

    Parameters:
    A list containing the count of each card rank in a poker hand.

    Returns:
    If two pairs are present, return 2; otherwise, return 0.

    Examples/Doctests:
    >>> two_pair([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    2
    >>> two_pair([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    0
    >>> two_pair([0, 1, 1, 1, 2, 1, 0, 1, 1, 2, 0, 0, 0])
    2
    """

    twos = []                                 #empty list
    for i in range(len(rank_list)):           #iterate through each rank count in the rank_list
        rank = rank_list[i]
        if rank == 2:
            twos.append(rank)
    if len(twos) == 2:
        return 2
    else:
        return 0


def one_pair(rank_list: list):
    """
    Determine if a poker hand has one pair.

    parameters:
    - rank_list (list): A list containing the count of each card rank in a poker hand.

    Returns:
    - int: If one pair is present, return 1; otherwise, return 0.

    Examples/Doctests:
    >>> one_pair([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    1
    >>> one_pair([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    0
    >>> one_pair([0, 1, 1, 1, 2, 1, 0, 1, 1, 2, 0, 0, 0])
    1
    """

    two = False 
    for i in range(len(rank_list)):             #iterate through each rank in rank list
        rank = rank_list[i]
        if rank == 2:                           #chack if there is a pair
            two = True                 
    if two:
        return 1
    else:
        return 0


#--------------TASK 5---------------      

def highest_card(rank_list: list):
    """
    Determine the rank of the highest card in a poker hand.

    Args:
    - rank_list (list): A list containing the count of each card rank in a poker hand.

    Returns:
    - int: The rank of the highest card in the hand.

    Example:
    >>> highest_card([0, 1, 1, 1, 2, 1, 0, 1, 1, 0, 0, 0, 0])
    4
    >>> highest_card([0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0])
    2
    >>> highest_card([0, 1, 1, 1, 2, 1, 0, 1, 1, 2, 0, 0, 0])
    9
    """
    rank_list.reverse() # Reverse the list to start from the highest rank
    # Iterate through the reversed rank_list
    for i in range(len(rank_list)):
        rank = rank_list[i]
        # Check if there is at least one card of the current rank
        if rank > 0:
            # Calculate the rank of the highest card
            highest_number = 13 - i
            break
    # Return the rank of the highest card in the hand
    return highest_number
									

def compare_hands(hand1: dict, hand2: dict) -> list:
    '''
    Accepts two hands, determines which hand wins, and prints the hands along with a description of the winning hand.
   
    Parameters:
    - hand1 (dict): First hand of cards.
    - hand2 (dict): Second hand of cards.

    Returns:
    - list: A list containing the winner designation and the rank of the winning hand.
    '''

    # Initialize base values for hand scores and empty strings for hand ranks text
    hand1_score, hand2_score = 0, 0
    hand1_rank, hand2_rank = "", ""

    # Create rank lists for each card hand
    hand1_rank_list = hand_ranks(hand1)
    hand2_rank_list = hand_ranks(hand2)

    # Call each function sequentially in order of specificity and rank
    for function, rank in [
        (straight_flush, "Straight Flush"),
        (four_of_a_kind, "Four of a Kind"),
        (full_house, "Full House"),
        (flush, "Flush"),
        (straight, "Straight"),
        (three_of_a_kind, "Three of a Kind"),
        (two_pair, "Two Pair"),
        (one_pair, "One Pair")
    ]:
        if hand1_score == 0:
            # Evaluate only if hand1 doesn't have a score yet
            # Some of these functions require a list...
            if function in [straight_flush, flush]:
                hand1_score = function(hand1)
            else:
                # Otherwise, evaluate using the hand rank list
                hand1_score = function(hand1_rank_list)
            hand1_rank = rank  # Assign rank

        # Do the same thing for the second hand of cards
        if hand2_score == 0:
            if function in [straight_flush, flush]:
                hand2_score = function(hand2)
            else:
                hand2_score = function(hand2_rank_list)
            hand2_rank = rank  # Assign rank

    # Determine the winner
    if hand1_score > hand2_score:
        # If hand1 wins
        winner, winning_rank = 1, hand1_rank
    elif hand2_score > hand1_score:
        # If hand2 wins
        winner, winning_rank = 2, hand2_rank
    elif hand1_score == hand2_score or hand1_score == 0 or hand2_score == 0:
        # Handle ties or no ranking
        hand1_score, hand2_score = highest_card(hand1), highest_card(hand2)
        winner, winning_rank = (1, "Highest Card") if hand1_score > hand2_score else (2, "Highest Card")
    else:
        # Failsafe in the rare scenario of identical hands
        winner, winning_rank = "NONE", "PERFECT TIE"

    return [winner, winning_rank]

def create_player_hand(player_hand: dict):
	'''
		Prints hand for player

		Parameters:
		dictionary representing the player hand
	'''
	print("PLAYER HAND")
	print("=============")
	print_hand(player_hand)

def create_computer_hand(computer_hand: dict):
	'''
		Prints hand for computer

		Parameters:
		dictionary representing the computer hand
	'''
	print("COMPUTER HAND")
	print("===============")
	print_hand(computer_hand)

def discard(hand: dict, deck: list):
    '''
    handles the discard portion of the program. Prompts player to discard a number of cards between
    0 and 4. Cards that the player wants to discard will be replaced with a new card from the deck. The discarded cards
    will be added to the end of the list which represents the deck

    Parameters:
    player's hand
    deck of cards
    Returns:
    Modified hand where the cards that the player selects to discard have been replaced
    '''
    player_hand_list = [card for suit in hand.values() for card in suit]

    discard_list = []
    print()
    
    # Prompt user to enter the number of cards to discard
    discard_number = input("How many cards would you like to discard? [0-4]: ")
    while not discard_number.isdigit() or not (0 <= int(discard_number) <= 4):
        discard_number = input("Please enter a number between 0 and 4: ")

    discard_number = int(discard_number)

    print()
    
    # Loop to select cards to discard
    for counter in range(1, discard_number + 1):
        card = input(f'({counter}/{discard_number}) Please select the card to discard [1-5]: ')
        
        # Validation loops
        while card in discard_list or not card.isdigit() or not (1 <= int(card) <= 5):
            if card in discard_list:
                card = input("You cannot discard the same card twice. Please enter a new card: ")
            else:
                card = input("Please enter a valid number between 1 and 5: ")

        card = int(card)
        print()

        discard_list.append(card)
        card_to_replace = player_hand_list[card - 1]

        # Update the deck
        deck.append(card_to_replace)
        new_card = deck.pop(0)

        # Update the player's hand
        for suit, cards in hand.items():
            for i in range(len(cards)):
                if cards[i] == card_to_replace:
                    cards[i] = new_card

    return hand

def computer_ai(computer_hand: dict):
	'''
		determines which cards to discard. 
        straight_flush or a flush then no cards will be discarded.
		If it has one pair, then the three cards that are not part of the pair will be discarded. 
        If it has a two pair, the only card with no pairing will be discarded

		Parameters:
		dictionary representing the computer's hand
		Returns:
		list of cards to discard for the computer hand
	'''
	computer_discard_list = []																	
	computer_ranks = hand_ranks(computer_hand)													# call hand_ranks function 
	if straight_flush(computer_hand) == 8 or flush(computer_hand) == 5:							# if computer has a straight flush or flush it will not discard anything
		return computer_hand
	if one_pair(computer_ranks) == 1:															# if computer has one pair it will discard the other three cards
		for rank in range(len(computer_ranks)):
			if computer_ranks[rank] == 2:
				matching_rank = rank + 1
		for suit in computer_hand:
			for card in computer_hand[suit]:
				if card[0] != matching_rank:
					computer_discard_list.append(card)
		return computer_discard_list
	
	matching_ranks_list = []																	
	if two_pair(computer_ranks) == 2:															# if computer has two pairs then it will only discard one card
		for rank in range(len(computer_ranks)):				
			if computer_ranks == 2:
				matching_ranks_list.append(rank + 1)										
		for suit in computer_hand:
			for card in computer_hand[suit]:
				if card[0] not in matching_ranks_list:                                          #if rank is not in the matching rank list. append it to discard
					computer_discard_list.append(card)
		return computer_discard_list

	else:
		for suit in computer_hand:
			for card in computer_hand[suit]:
				computer_discard_list.append(card)
		computer_discard_list.pop(1)
		computer_discard_list.pop(2)
		return computer_discard_list
