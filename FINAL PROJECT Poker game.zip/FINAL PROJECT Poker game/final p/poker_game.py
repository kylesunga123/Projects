import kyle_poker

user_input = "Y"
hands = 2
user_input_list = ["Y", "N"]                                                              #alist w/ inputs
while user_input != "N":                                                                  # runs untiul u say no
    hand_list = kyle_poker.deal_hands(hands)                                         # call deal function. give 2 hands
    player_hand = hand_list[0]                                                            #players hand first
    computer_hand = hand_list[1]                                                          
    kyle_poker.create_player_hand(player_hand)                                       # call function creats player hand
    new_hand = kyle_poker.discard(player_hand)                                       # discard function
    new_computer_hand = kyle_poker.computer_discard(computer_hand)                   
    kyle_poker.create_computer_hand(new_computer_hand)                               # use the create_computer_hand function to print the computer hand
    print()
    kyle_poker.create_player_hand(new_hand)                                          # print the modified player hand
    print()
    new_hand_list = [player_hand,new_computer_hand]
    print(kyle_poker.compare_hands(new_hand_list))                                   # call function to determine winner
    user_input = input("Would you like to play again? (Y/N):")                            # prompt user to enter Yes or no
    user_input.upper()
    while user_input not in user_input_list:                                              #ask again
        user_input = input("Please enter Y to play again or N if you would like to stop playing: ")