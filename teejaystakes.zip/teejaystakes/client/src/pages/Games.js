import React, { useState, useEffect } from 'react';
import api from '../utils/api';

export default function Games() {
  const [games, setGames] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [showPickForm, setShowPickForm] = useState(null);
  const [form, setForm] = useState({
    home_team: '', away_team: '', game_date: '',
    full_game_spread: '', full_game_favorite: '',
    h1_spread: '', h1_favorite: ''
  });
  const [pickForm, setPickForm] = useState({ pick_type: 'full', picked_team: '', spread: '', notes: '' });

  const TEAMS = [
    'Golden State Warriors', 'Los Angeles Lakers', 'New York Knicks',
    'Milwaukee Bucks', 'San Antonio Spurs', 'Denver Nuggets',
    'Miami Heat', 'Oklahoma City Thunder',
    'Boston Celtics', 'Phoenix Suns', 'Dallas Mavericks',
    'Memphis Grizzlies', 'Cleveland Cavaliers', 'Philadelphia 76ers',
    'Brooklyn Nets', 'Chicago Bulls', 'Atlanta Hawks',
    'Toronto Raptors', 'Minnesota Timberwolves', 'Utah Jazz',
    'Portland Trail Blazers', 'Sacramento Kings', 'New Orleans Pelicans',
    'Indiana Pacers', 'Charlotte Hornets', 'Washington Wizards',
    'Orlando Magic', 'Detroit Pistons', 'Houston Rockets', 'Los Angeles Clippers'
  ].sort();

  useEffect(() => { loadGames(); }, []);

  const loadGames = async () => {
    const res = await api.get('/games');
    setGames(res.data);
  };

  const handleSubmitGame = async (e) => {
    e.preventDefault();
    await api.post('/games', form);
    setShowForm(false);
    setForm({ home_team: '', away_team: '', game_date: '', full_game_spread: '', full_game_favorite: '', h1_spread: '', h1_favorite: '' });
    loadGames();
  };

  const handleSubmitPick = async (e) => {
    e.preventDefault();
    await api.post('/picks', { game_id: showPickForm, ...pickForm });
    setShowPickForm(null);
    setPickForm({ pick_type: 'full', picked_team: '', spread: '', notes: '' });
  };

  const updateScore = async (gameId, field, value) => {
    await api.patch(`/games/${gameId}`, { [field]: parseInt(value), status: 'final' });
    loadGames();
  };

  const getGame = (id) => games.find(g => g.id === id);

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Games</h2>
        <button onClick={() => setShowForm(!showForm)}>+ Add Game Manually</button>
      </div>

      {showForm && (
        <div className="card">
          <h3>Add Game</h3>
          <form onSubmit={handleSubmitGame}>
            <div className="form-row">
              <div>
                <label>Away Team</label>
                <select value={form.away_team} onChange={e => setForm({ ...form, away_team: e.target.value })} required>
                  <option value="">Select...</option>
                  {TEAMS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label>Home Team</label>
                <select value={form.home_team} onChange={e => setForm({ ...form, home_team: e.target.value })} required>
                  <option value="">Select...</option>
                  {TEAMS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="form-row">
              <div>
                <label>Game Date/Time</label>
                <input type="datetime-local" value={form.game_date} onChange={e => setForm({ ...form, game_date: e.target.value })} required />
              </div>
            </div>
            <div className="form-row">
              <div>
                <label>Full Game Spread</label>
                <input type="number" step="0.5" placeholder="e.g. 6.5" value={form.full_game_spread} onChange={e => setForm({ ...form, full_game_spread: e.target.value })} />
              </div>
              <div>
                <label>Full Game Favorite</label>
                <select value={form.full_game_favorite} onChange={e => setForm({ ...form, full_game_favorite: e.target.value })}>
                  <option value="">Select...</option>
                  {form.home_team && <option value={form.home_team}>{form.home_team}</option>}
                  {form.away_team && <option value={form.away_team}>{form.away_team}</option>}
                </select>
              </div>
            </div>
            <div className="form-row">
              <div>
                <label>H1 Spread</label>
                <input type="number" step="0.5" placeholder="e.g. 3.5" value={form.h1_spread} onChange={e => setForm({ ...form, h1_spread: e.target.value })} />
              </div>
              <div>
                <label>H1 Favorite</label>
                <select value={form.h1_favorite} onChange={e => setForm({ ...form, h1_favorite: e.target.value })}>
                  <option value="">Select...</option>
                  {form.home_team && <option value={form.home_team}>{form.home_team}</option>}
                  {form.away_team && <option value={form.away_team}>{form.away_team}</option>}
                </select>
              </div>
            </div>
            <button type="submit">Save Game</button>
            <button type="button" className="secondary" style={{ marginLeft: 8 }} onClick={() => setShowForm(false)}>Cancel</button>
          </form>
        </div>
      )}

      {/* Pick Form Modal */}
      {showPickForm && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 }}>
          <div style={{ background: '#fff', padding: 24, width: 400 }}>
            <h3 style={{ marginBottom: 16 }}>Enter Pick</h3>
            {getGame(showPickForm) && (
              <div style={{ marginBottom: 12, fontSize: 13, color: '#555' }}>
                {getGame(showPickForm).away_team} @ {getGame(showPickForm).home_team}
              </div>
            )}
            <form onSubmit={handleSubmitPick}>
              <label>Pick Type</label>
              <select value={pickForm.pick_type} onChange={e => setPickForm({ ...pickForm, pick_type: e.target.value })}>
                <option value="full">Full Game ATS</option>
                <option value="h1">1st Half ATS</option>
              </select>
              <label>Team Picked</label>
              <select value={pickForm.picked_team} onChange={e => setPickForm({ ...pickForm, picked_team: e.target.value })} required>
                <option value="">Select...</option>
                {getGame(showPickForm) && (
                  <>
                    <option value={getGame(showPickForm).away_team}>{getGame(showPickForm).away_team}</option>
                    <option value={getGame(showPickForm).home_team}>{getGame(showPickForm).home_team}</option>
                  </>
                )}
              </select>
              <label>Spread</label>
              <input type="number" step="0.5" value={pickForm.spread} onChange={e => setPickForm({ ...pickForm, spread: e.target.value })} />
              <label>Notes</label>
              <textarea rows={2} value={pickForm.notes} onChange={e => setPickForm({ ...pickForm, notes: e.target.value })} />
              <button type="submit">Save Pick</button>
              <button type="button" className="secondary" style={{ marginLeft: 8 }} onClick={() => setShowPickForm(null)}>Cancel</button>
            </form>
          </div>
        </div>
      )}

      <div className="card">
        <h3>All Games</h3>
        {games.length === 0 ? (
          <div style={{ color: '#888' }}>No games yet. Add manually or refresh odds from Dashboard.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Matchup</th>
                <th>Full Spread</th>
                <th>H1 Spread</th>
                <th>Status</th>
                <th>Score</th>
                <th>H1 Score</th>
                <th>Result</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {games.map(g => (
                <tr key={g.id}>
                  <td>{new Date(g.game_date).toLocaleDateString()}</td>
                  <td><strong>{g.away_team.split(' ').pop()}</strong> @ {g.home_team.split(' ').pop()}</td>
                  <td>
                    {g.full_game_favorite && g.full_game_spread
                      ? `${g.full_game_favorite.split(' ').pop()} -${g.full_game_spread}`
                      : '—'}
                  </td>
                  <td>
                    {g.h1_favorite && g.h1_spread
                      ? `${g.h1_favorite.split(' ').pop()} -${g.h1_spread}`
                      : '—'}
                  </td>
                  <td><span className="badge badge-pending">{g.status}</span></td>
                  <td>
                    {g.status === 'final'
                      ? `${g.away_score}-${g.home_score}`
                      : (
                        <div style={{ display: 'flex', gap: 4 }}>
                          <input type="number" placeholder="Away" style={{ width: 50, marginBottom: 0 }}
                            onBlur={e => e.target.value && updateScore(g.id, 'away_score', e.target.value)} />
                          <input type="number" placeholder="Home" style={{ width: 50, marginBottom: 0 }}
                            onBlur={e => e.target.value && updateScore(g.id, 'home_score', e.target.value)} />
                        </div>
                      )
                    }
                  </td>
                  <td>
                    {g.home_score_h1
                      ? `${g.away_score_h1}-${g.home_score_h1}`
                      : (
                        <div style={{ display: 'flex', gap: 4 }}>
                          <input type="number" placeholder="A" style={{ width: 40, marginBottom: 0 }}
                            onBlur={e => e.target.value && updateScore(g.id, 'away_score_h1', e.target.value)} />
                          <input type="number" placeholder="H" style={{ width: 40, marginBottom: 0 }}
                            onBlur={e => e.target.value && updateScore(g.id, 'home_score_h1', e.target.value)} />
                        </div>
                      )
                    }
                  </td>
                  <td>
                    {g.h1_result ? (
                      <span className={`badge badge-${g.h1_result.includes('cover') ? 'win' : 'push'}`}>
                        H1: {g.h1_result}
                      </span>
                    ) : '—'}
                  </td>
                  <td>
                    <button style={{ fontSize: 11, padding: '4px 8px' }} onClick={() => setShowPickForm(g.id)}>
                      + Pick
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
