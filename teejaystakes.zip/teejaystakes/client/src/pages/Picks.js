import React, { useState, useEffect } from 'react';
import api from '../utils/api';

export default function Picks() {
  const [picks, setPicks] = useState([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => { loadPicks(); }, []);

  const loadPicks = async () => {
    const res = await api.get('/picks');
    setPicks(res.data);
  };

  const filtered = filter === 'all' ? picks : picks.filter(p => p.result === filter);

  const wins = picks.filter(p => p.result === 'win').length;
  const losses = picks.filter(p => p.result === 'loss').length;
  const pushes = picks.filter(p => p.result === 'push').length;
  const pending = picks.filter(p => p.result === 'pending').length;
  const winPct = wins + losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : '—';

  return (
    <div>
      <div className="page-header"><h2>My Picks</h2></div>

      <div className="grid-3" style={{ marginBottom: 16 }}>
        <div className="stat-box">
          <div className="num" style={{ color: '#155724' }}>{wins}</div>
          <div className="label">WINS</div>
        </div>
        <div className="stat-box">
          <div className="num" style={{ color: '#721c24' }}>{losses}</div>
          <div className="label">LOSSES</div>
        </div>
        <div className="stat-box">
          <div className="num">{winPct}{winPct !== '—' ? '%' : ''}</div>
          <div className="label">WIN %</div>
        </div>
      </div>

      <div style={{ marginBottom: 12, display: 'flex', gap: 8 }}>
        {['all', 'pending', 'win', 'loss', 'push'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={filter === f ? '' : 'secondary'}
            style={{ fontSize: 12, padding: '4px 12px' }}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
            {f === 'pending' && pending > 0 ? ` (${pending})` : ''}
          </button>
        ))}
      </div>

      <div className="card">
        <h3>Pick History</h3>
        {filtered.length === 0 ? (
          <div style={{ color: '#888' }}>No picks yet. Go to Games to add picks.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Game</th>
                <th>Type</th>
                <th>My Pick</th>
                <th>Spread</th>
                <th>Result</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id}>
                  <td>{new Date(p.game_date).toLocaleDateString()}</td>
                  <td>{p.away_team?.split(' ').pop()} @ {p.home_team?.split(' ').pop()}</td>
                  <td>{p.pick_type === 'h1' ? '1st Half' : 'Full Game'}</td>
                  <td><strong>{p.picked_team?.split(' ').pop()}</strong></td>
                  <td>{p.spread ? `-${p.spread}` : '—'}</td>
                  <td>
                    <span className={`badge badge-${p.result}`}>
                      {p.result?.charAt(0).toUpperCase() + p.result?.slice(1)}
                    </span>
                  </td>
                  <td style={{ color: '#888', fontSize: 12 }}>{p.notes || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
