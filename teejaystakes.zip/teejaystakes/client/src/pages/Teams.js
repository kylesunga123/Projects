import React, { useState, useEffect } from 'react';
import api from '../utils/api';

const MAIN_TEAMS = ['Golden State Warriors', 'Los Angeles Lakers', 'New York Knicks'];

export default function Teams() {
  const [teams, setTeams] = useState([]);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);

  useEffect(() => { loadTeams(); }, []);

  const loadTeams = async () => {
    const res = await api.get('/teams');
    setTeams(res.data);
  };

  const loadTeamDetail = async (team) => {
    if (selected === team) {
      setSelected(null);
      setDetail(null);
      return;
    }
    setSelected(team);
    const res = await api.get(`/teams/${encodeURIComponent(team)}`);
    setDetail(res.data);
  };

  const formatATS = (s, h1 = false) => {
    const w = h1 ? s.h1_ats_wins : s.ats_wins;
    const l = h1 ? s.h1_ats_losses : s.ats_losses;
    const p = h1 ? s.h1_ats_pushes : s.ats_pushes;
    return `${w || 0}-${l || 0}${p ? `-${p}` : ''}`;
  };

  const mainTeams = teams.filter(t => MAIN_TEAMS.includes(t.team));
  const otherTeams = teams.filter(t => !MAIN_TEAMS.includes(t.team));

  return (
    <div>
      <div className="page-header"><h2>Teams</h2></div>

      <div className="card">
        <h3>Main Teams</h3>
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th>Full ATS</th>
              <th>H1 ATS</th>
              <th>H1 Streak</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {mainTeams.map(s => (
              <React.Fragment key={s.team}>
                <tr style={{ background: selected === s.team ? '#f0f0f0' : '' }}>
                  <td><strong>{s.team}</strong></td>
                  <td>{formatATS(s)}</td>
                  <td>{formatATS(s, true)}</td>
                  <td>
                    {s.h1_streak >= 1 ? (
                      <span className={`streak-${s.h1_streak_type}`}>
                        {s.h1_streak}-game {s.h1_streak_type}
                      </span>
                    ) : '—'}
                  </td>
                  <td>
                    <button style={{ fontSize: 11, padding: '4px 8px' }} onClick={() => loadTeamDetail(s.team)}>
                      {selected === s.team ? 'Hide' : 'Detail'}
                    </button>
                  </td>
                </tr>
                {selected === s.team && detail && (
                  <tr>
                    <td colSpan={5} style={{ background: '#f9f9f9', padding: 16 }}>
                      <strong>Last 10 Games</strong>
                      {detail.recentGames.length === 0 ? (
                        <div style={{ color: '#888', marginTop: 8 }}>No game history yet.</div>
                      ) : (
                        <table style={{ marginTop: 8 }}>
                          <thead>
                            <tr>
                              <th>Date</th>
                              <th>Opponent</th>
                              <th>Score</th>
                              <th>H1 Result</th>
                              <th>Full Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            {detail.recentGames.map(g => (
                              <tr key={g.id}>
                                <td>{new Date(g.game_date).toLocaleDateString()}</td>
                                <td>{g.home_team === s.team ? `vs ${g.away_team.split(' ').pop()}` : `@ ${g.home_team.split(' ').pop()}`}</td>
                                <td>{g.status === 'final' ? `${g.away_score}-${g.home_score}` : '—'}</td>
                                <td>{g.h1_result || '—'}</td>
                                <td>{g.result || '—'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3>Other Tracked Teams</h3>
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th>Full ATS</th>
              <th>H1 ATS</th>
              <th>H1 Streak</th>
            </tr>
          </thead>
          <tbody>
            {otherTeams.map(s => (
              <tr key={s.team}>
                <td>{s.team}</td>
                <td>{formatATS(s)}</td>
                <td>{formatATS(s, true)}</td>
                <td>
                  {s.h1_streak >= 1 ? (
                    <span className={`streak-${s.h1_streak_type}`}>
                      {s.h1_streak}-game {s.h1_streak_type}
                    </span>
                  ) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
