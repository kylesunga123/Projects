import React, { useState, useEffect } from 'react';
import api from '../utils/api';

const MAIN_TEAMS = ['Golden State Warriors', 'Los Angeles Lakers', 'New York Knicks'];

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const res = await api.get('/dashboard');
      setData(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const refreshOdds = async () => {
    try {
      await api.post('/games/refresh');
      loadDashboard();
    } catch (err) {
      alert('Error refreshing odds. Check your API key.');
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!data) return <div>Error loading data.</div>;

  const { todayGames, teamStats, pickRecord, streaks } = data;

  const getTeamStats = (teamName) =>
    teamStats.find(t => t.team === teamName) || {};

  const formatATS = (stats, h1 = false) => {
    const w = h1 ? stats.h1_ats_wins : stats.ats_wins;
    const l = h1 ? stats.h1_ats_losses : stats.ats_losses;
    const p = h1 ? stats.h1_ats_pushes : stats.ats_pushes;
    if (!w && !l && !p) return '0-0';
    return `${w || 0}-${l || 0}${p ? `-${p}` : ''}`;
  };

  return (
    <div>
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Dashboard</h2>
        <button onClick={refreshOdds}>Refresh Odds</button>
      </div>

      {/* Streak Alerts */}
      {streaks && streaks.length > 0 && (
        <div className="alert-banner">
          🔥 Active Streaks: {streaks.map(s => (
            <strong key={s.team}> {s.team} ({s.h1_streak}-game H1 {s.h1_streak_type})</strong>
          ))}
        </div>
      )}

      {/* Pick Record */}
      <div className="grid-3" style={{ marginBottom: 16 }}>
        <div className="stat-box">
          <div className="num" style={{ color: '#155724' }}>{pickRecord?.wins || 0}</div>
          <div className="label">MY PICKS - WINS</div>
        </div>
        <div className="stat-box">
          <div className="num" style={{ color: '#721c24' }}>{pickRecord?.losses || 0}</div>
          <div className="label">MY PICKS - LOSSES</div>
        </div>
        <div className="stat-box">
          <div className="num">{pickRecord?.pending || 0}</div>
          <div className="label">PENDING</div>
        </div>
      </div>

      {/* Main 3 Teams */}
      <div className="main-teams">
        {MAIN_TEAMS.map(team => {
          const s = getTeamStats(team);
          const streak = s.h1_streak || 0;
          const streakType = s.h1_streak_type;
          return (
            <div className="team-card" key={team}>
              <h3>{team}</h3>
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: '#888' }}>FULL GAME ATS</div>
                <div className="team-record">{formatATS(s)} <span>ATS</span></div>
              </div>
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 11, color: '#888' }}>1ST HALF ATS</div>
                <div className="team-record">{formatATS(s, true)} <span>H1 ATS</span></div>
              </div>
              {streak >= 2 && (
                <div className={`streak-${streakType}`} style={{ fontSize: 12 }}>
                  {streak}-game H1 {streakType} streak
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Today's Games */}
      <div className="card">
        <h3>Today's Games ({todayGames.length})</h3>
        {todayGames.length === 0 ? (
          <div style={{ color: '#888', fontSize: 13 }}>No games today or odds not loaded yet. Click "Refresh Odds".</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Game</th>
                <th>Time</th>
                <th>Full Game Spread</th>
                <th>H1 Spread</th>
                <th>Line Move</th>
                <th>Status</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {todayGames.map(g => {
                const lineMove = g.full_game_spread && g.opening_spread
                  ? (g.full_game_spread - g.opening_spread).toFixed(1)
                  : null;
                return (
                  <tr key={g.id}>
                    <td><strong>{g.away_team}</strong> @ {g.home_team}</td>
                    <td>{new Date(g.game_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                    <td>
                      {g.full_game_favorite && g.full_game_spread ? (
                        <span>{g.full_game_favorite.split(' ').pop()} -{g.full_game_spread}</span>
                      ) : '—'}
                    </td>
                    <td>
                      {g.h1_favorite && g.h1_spread ? (
                        <span>{g.h1_favorite.split(' ').pop()} -{g.h1_spread}</span>
                      ) : '—'}
                    </td>
                    <td>
                      {lineMove && lineMove !== '0.0' ? (
                        <span style={{ color: parseFloat(lineMove) > 0 ? 'green' : 'red' }}>
                          {lineMove > 0 ? '+' : ''}{lineMove}
                        </span>
                      ) : '—'}
                    </td>
                    <td><span className="badge badge-pending">{g.status}</span></td>
                    <td>{g.status === 'final' ? `${g.away_score}-${g.home_score}` : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Secondary Teams */}
      <div className="card">
        <h3>All Tracked Teams — H1 ATS</h3>
        <table>
          <thead>
            <tr>
              <th>Team</th>
              <th>H1 ATS</th>
              <th>Full ATS</th>
              <th>H1 Streak</th>
            </tr>
          </thead>
          <tbody>
            {teamStats.map(s => (
              <tr key={s.team}>
                <td>{s.team}</td>
                <td>{formatATS(s, true)}</td>
                <td>{formatATS(s)}</td>
                <td>
                  {s.h1_streak >= 1 ? (
                    <span className={`streak-${s.h1_streak_type}`}>
                      {s.h1_streak}-game {s.h1_streak_type}
                    </span>
                  ) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
