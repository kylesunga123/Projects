import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Games from './pages/Games';
import Picks from './pages/Picks';
import Teams from './pages/Teams';

function Layout({ onLogout }) {
  return (
    <div className="app">
      <div className="sidebar">
        <h1>TeeJayStakes</h1>
        <nav>
          <NavLink to="/dashboard">Dashboard</NavLink>
          <NavLink to="/games">Games</NavLink>
          <NavLink to="/picks">My Picks</NavLink>
          <NavLink to="/teams">Teams</NavLink>
        </nav>
        <div style={{ position: 'absolute', bottom: 16, left: 0, right: 0, padding: '0 16px' }}>
          <button className="secondary" style={{ width: '100%', fontSize: 11, background: 'transparent', color: '#888', border: '1px solid #444' }} onClick={onLogout}>
            Logout
          </button>
        </div>
      </div>
      <div className="main-content">
        <Routes>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/games" element={<Games />} />
          <Route path="/picks" element={<Picks />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </div>
    </div>
  );
}

export default function App() {
  const [authed, setAuthed] = useState(!!localStorage.getItem('tjs_token'));

  const handleLogin = () => setAuthed(true);
  const handleLogout = () => {
    localStorage.removeItem('tjs_token');
    setAuthed(false);
  };

  if (!authed) return <Login onLogin={handleLogin} />;

  return (
    <BrowserRouter>
      <Layout onLogout={handleLogout} />
    </BrowserRouter>
  );
}
