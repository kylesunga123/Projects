const axios = require('axios');
require('dotenv').config();

const ODDS_API_KEY = process.env.ODDS_API_KEY;
const BASE_URL = 'https://api.the-odds-api.com/v4';

const TRACKED_TEAMS = [
  'Golden State Warriors',
  'Los Angeles Lakers',
  'New York Knicks',
  'Milwaukee Bucks',
  'San Antonio Spurs',
  'Denver Nuggets',
  'Miami Heat',
  'Oklahoma City Thunder'
];

async function getNBAGames() {
  try {
    const response = await axios.get(`${BASE_URL}/sports/basketball_nba/odds`, {
      params: {
        apiKey: ODDS_API_KEY,
        regions: 'us',
        markets: 'spreads',
        oddsFormat: 'american',
        dateFormat: 'iso'
      }
    });
    return response.data;
  } catch (err) {
    console.error('Error fetching NBA odds:', err.message);
    return [];
  }
}

async function getNBAH1Odds() {
  try {
    const response = await axios.get(`${BASE_URL}/sports/basketball_nba/odds`, {
      params: {
        apiKey: ODDS_API_KEY,
        regions: 'us',
        markets: 'spreads',
        oddsFormat: 'american',
        dateFormat: 'iso'
      }
    });
    // Filter for first half markets if available
    return response.data;
  } catch (err) {
    console.error('Error fetching H1 odds:', err.message);
    return [];
  }
}

async function getNBAScores() {
  try {
    const response = await axios.get(`${BASE_URL}/sports/basketball_nba/scores`, {
      params: {
        apiKey: ODDS_API_KEY,
        daysFrom: 1
      }
    });
    return response.data;
  } catch (err) {
    console.error('Error fetching scores:', err.message);
    return [];
  }
}

function parseSpread(oddsData) {
  const games = [];
  
  for (const game of oddsData) {
    const homeTeam = game.home_team;
    const awayTeam = game.away_team;
    
    // Only process tracked teams
    const isTracked = TRACKED_TEAMS.some(t => 
      homeTeam.includes(t.split(' ').pop()) || 
      awayTeam.includes(t.split(' ').pop())
    );
    
    if (!isTracked) continue;

    let spread = null;
    let favorite = null;

    if (game.bookmakers && game.bookmakers.length > 0) {
      const bookmaker = game.bookmakers.find(b => b.key === 'draftkings') || game.bookmakers[0];
      const spreadMarket = bookmaker.markets.find(m => m.key === 'spreads');
      
      if (spreadMarket) {
        const homeOutcome = spreadMarket.outcomes.find(o => o.name === homeTeam);
        if (homeOutcome) {
          spread = Math.abs(homeOutcome.point);
          favorite = homeOutcome.point < 0 ? homeTeam : awayTeam;
        }
      }
    }

    games.push({
      id: game.id,
      home_team: homeTeam,
      away_team: awayTeam,
      game_date: game.commence_time,
      full_game_spread: spread,
      full_game_favorite: favorite,
      opening_spread: spread,
      opening_favorite: favorite
    });
  }
  
  return games;
}

module.exports = { getNBAGames, getNBAH1Odds, getNBAScores, parseSpread, TRACKED_TEAMS };
