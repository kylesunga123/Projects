const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

async function sendStreakAlert(team, streakCount, streakType, isHalftime = true) {
  const subject = `🔥 TeeJayStakes Alert: ${team} ${streakCount}-Game ${streakType.toUpperCase()} Streak`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">TeeJayStakes Streak Alert</h2>
      <div style="background: ${streakType === 'win' ? '#d4edda' : '#f8d7da'}; padding: 20px; border-radius: 8px;">
        <h3 style="color: ${streakType === 'win' ? '#155724' : '#721c24'};">
          ${team} - ${streakCount} ${isHalftime ? 'Halftime' : 'Full Game'} ATS ${streakType === 'win' ? 'Wins' : 'Losses'} in a Row
        </h3>
        <p>Team: <strong>${team}</strong></p>
        <p>Streak: <strong>${streakCount} consecutive ${isHalftime ? 'halftime' : ''} ATS ${streakType === 'win' ? 'covers' : 'misses'}</strong></p>
        <p>Time: ${new Date().toLocaleString()}</p>
      </div>
      <p style="color: #666; font-size: 12px; margin-top: 20px;">
        TeeJayStakes - NBA Spread Tracker
      </p>
    </div>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.ALERT_EMAIL,
      subject,
      html
    });
    console.log(`Streak alert sent for ${team}`);
    return true;
  } catch (err) {
    console.error('Error sending email:', err.message);
    return false;
  }
}

async function sendLineMovementAlert(team, oldSpread, newSpread, game) {
  const movement = Math.abs(newSpread - oldSpread);
  if (movement < 2) return; // Only alert for 2+ point moves

  const subject = `📊 TeeJayStakes: Line Movement - ${team} (${movement > 0 ? '+' : ''}${movement} pts)`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #333;">Line Movement Alert</h2>
      <div style="background: #fff3cd; padding: 20px; border-radius: 8px;">
        <h3>${game.away_team} @ ${game.home_team}</h3>
        <p>Opening Line: <strong>${oldSpread}</strong></p>
        <p>Current Line: <strong>${newSpread}</strong></p>
        <p>Movement: <strong>${movement} points</strong></p>
        <p>Game Time: ${new Date(game.game_date).toLocaleString()}</p>
      </div>
    </div>
  `;

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.ALERT_EMAIL,
      subject,
      html
    });
    return true;
  } catch (err) {
    console.error('Error sending line movement alert:', err.message);
    return false;
  }
}

module.exports = { sendStreakAlert, sendLineMovementAlert };
