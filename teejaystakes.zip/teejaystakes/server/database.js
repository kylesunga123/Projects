const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'teejaystakes.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS games (
    id TEXT PRIMARY KEY,
    home_team TEXT NOT NULL,
    away_team TEXT NOT NULL,
    game_date TEXT NOT NULL,
    status TEXT DEFAULT 'scheduled',
    home_score INTEGER DEFAULT 0,
    away_score INTEGER DEFAULT 0,
    home_score_h1 INTEGER DEFAULT 0,
    away_score_h1 INTEGER DEFAULT 0,
    full_game_spread REAL,
    full_game_favorite TEXT,
    h1_spread REAL,
    h1_favorite TEXT,
    opening_spread REAL,
    opening_favorite TEXT,
    result TEXT,
    h1_result TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS picks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id TEXT NOT NULL,
    pick_type TEXT NOT NULL,
    picked_team TEXT NOT NULL,
    spread REAL,
    result TEXT DEFAULT 'pending',
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (game_id) REFERENCES games(id)
  );

  CREATE TABLE IF NOT EXISTS team_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team TEXT NOT NULL,
    season TEXT NOT NULL,
    ats_wins INTEGER DEFAULT 0,
    ats_losses INTEGER DEFAULT 0,
    ats_pushes INTEGER DEFAULT 0,
    h1_ats_wins INTEGER DEFAULT 0,
    h1_ats_losses INTEGER DEFAULT 0,
    h1_ats_pushes INTEGER DEFAULT 0,
    h1_streak INTEGER DEFAULT 0,
    h1_streak_type TEXT DEFAULT 'none',
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(team, season)
  );

  CREATE TABLE IF NOT EXISTS streak_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team TEXT NOT NULL,
    streak_count INTEGER NOT NULL,
    streak_type TEXT NOT NULL,
    alert_sent INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Initialize team stats for tracked teams
const trackedTeams = [
  'Golden State Warriors',
  'Los Angeles Lakers', 
  'New York Knicks',
  'Milwaukee Bucks',
  'San Antonio Spurs',
  'Denver Nuggets',
  'Miami Heat',
  'Oklahoma City Thunder'
];

const insertTeam = db.prepare(`
  INSERT OR IGNORE INTO team_stats (team, season) VALUES (?, '2024-25')
`);

trackedTeams.forEach(team => insertTeam.run(team));

module.exports = db;
