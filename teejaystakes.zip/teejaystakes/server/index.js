const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cron = require('node-cron');
require('dotenv').config();

const db = require('./database');
const { getNBAGames, getNBAScores, parseSpread, TRACKED_TEAMS } = require('./oddsService');
const { sendStreakAlert } = require('./emailService');

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'teejaystakes_secret';
const SITE_PASSWORD = process.env.SITE_PASSWORD || '2014437054';

// ─── AUTH MIDDLEWARE ───────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// ─── AUTH ROUTES ───────────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { password } = req.body;
  if (password === SITE_PASSWORD) {
    const token = jwt.sign({ access: true }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token });
  } else {
    res.status(401).json({ error: 'Wrong password' });
  }
});

// ─── GAMES ROUTES ─────────────────────────────────────────────────
app.get('/api/games', authMiddleware, (req, res) => {
  const { date, status } = req.query;
  let query = 'SELECT * FROM games WHERE 1=1';
  const params = [];

  if (date) {
    query += ' AND date(game_date) = ?';
    params.push(date);
  }
  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  query += ' ORDER BY game_date ASC';
  const games = db.prepare(query).all(...params);
  res.json(games);
});

app.get('/api/games/today', authMiddleware, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const games = db.prepare(`
    SELECT * FROM games 
    WHERE date(game_date) = date('now', 'localtime')
    ORDER BY game_date ASC
  `).all();
  res.json(games);
});

app.post('/api/games/refresh', authMiddleware, async (req, res) => {
  try {
    const oddsData = await getNBAGames();
    const parsed = parseSpread(oddsData);
    
    const upsert = db.prepare(`
      INSERT INTO games (id, home_team, away_team, game_date, full_game_spread, full_game_favorite, opening_spread, opening_favorite)
      VALUES (@id, @home_team, @away_team, @game_date, @full_game_spread, @full_game_favorite, @opening_spread, @opening_favorite)
      ON CONFLICT(id) DO UPDATE SET
        full_game_spread = excluded.full_game_spread,
        full_game_favorite = excluded.full_game_favorite,
        updated_at = datetime('now')
    `);

    const insertMany = db.transaction((games) => {
      for (const game of games) upsert.run(game);
    });

    insertMany(parsed);
    res.json({ success: true, count: parsed.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Manual game entry
app.post('/api/games', authMiddleware, (req, res) => {
  const { home_team, away_team, game_date, full_game_spread, full_game_favorite, h1_spread, h1_favorite } = req.body;
  const id = `manual_${Date.now()}`;
  
  try {
    db.prepare(`
      INSERT INTO games (id, home_team, away_team, game_date, full_game_spread, full_game_favorite, h1_spread, h1_favorite, opening_spread, opening_favorite)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, home_team, away_team, game_date, full_game_spread, full_game_favorite, h1_spread, h1_favorite, full_game_spread, full_game_favorite);
    
    res.json({ success: true, id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/games/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const updates = req.body;
  
  const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
  const values = [...Object.values(updates), id];
  
  db.prepare(`UPDATE games SET ${fields}, updated_at = datetime('now') WHERE id = ?`).run(...values);
  
  // If scores updated, calculate results
  if (updates.home_score !== undefined || updates.away_score !== undefined) {
    updateGameResult(id);
  }
  
  res.json({ success: true });
});

// ─── PICKS ROUTES ─────────────────────────────────────────────────
app.get('/api/picks', authMiddleware, (req, res) => {
  const picks = db.prepare(`
    SELECT p.*, g.home_team, g.away_team, g.game_date, g.full_game_spread, g.h1_spread,
           g.home_score, g.away_score, g.status
    FROM picks p
    JOIN games g ON p.game_id = g.id
    ORDER BY g.game_date DESC
  `).all();
  res.json(picks);
});

app.post('/api/picks', authMiddleware, (req, res) => {
  const { game_id, pick_type, picked_team, spread, notes } = req.body;
  
  try {
    const result = db.prepare(`
      INSERT INTO picks (game_id, pick_type, picked_team, spread, notes)
      VALUES (?, ?, ?, ?, ?)
    `).run(game_id, pick_type, picked_team, spread, notes);
    
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── TEAM STATS ROUTES ─────────────────────────────────────────────
app.get('/api/teams', authMiddleware, (req, res) => {
  const stats = db.prepare('SELECT * FROM team_stats ORDER BY h1_ats_wins DESC').all();
  res.json(stats);
});

app.get('/api/teams/:team', authMiddleware, (req, res) => {
  const team = decodeURIComponent(req.params.team);
  const stats = db.prepare('SELECT * FROM team_stats WHERE team = ?').get(team);
  
  const recentGames = db.prepare(`
    SELECT g.*, p.picked_team, p.result as pick_result
    FROM games g
    LEFT JOIN picks p ON g.id = p.game_id
    WHERE g.home_team = ? OR g.away_team = ?
    ORDER BY g.game_date DESC
    LIMIT 10
  `).all(team, team);
  
  res.json({ stats, recentGames });
});

// ─── STREAK CHECKER ───────────────────────────────────────────────
function checkStreaks() {
  const teams = TRACKED_TEAMS;
  
  for (const team of teams) {
    const stats = db.prepare('SELECT * FROM team_stats WHERE team = ?').get(team);
    if (!stats) continue;
    
    const streak = Math.abs(stats.h1_streak);
    const streakType = stats.h1_streak_type;
    
    if (streak >= 3) {
      const recent = db.prepare(`
        SELECT * FROM streak_alerts 
        WHERE team = ? AND streak_count = ? AND streak_type = ?
        AND created_at > datetime('now', '-1 day')
      `).get(team, streak, streakType);
      
      if (!recent) {
        db.prepare(`
          INSERT INTO streak_alerts (team, streak_count, streak_type) VALUES (?, ?, ?)
        `).run(team, streak, streakType);
        
        sendStreakAlert(team, streak, streakType, true);
      }
    }
  }
}

// ─── RESULT CALCULATOR ────────────────────────────────────────────
function updateGameResult(gameId) {
  const game = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId);
  if (!game || game.status !== 'final') return;
  
  // Full game ATS result
  if (game.full_game_spread && game.full_game_favorite) {
    const favScore = game.home_team === game.full_game_favorite ? game.home_score : game.away_score;
    const dogScore = game.home_team === game.full_game_favorite ? game.away_score : game.home_score;
    const margin = favScore - dogScore;
    
    let result;
    if (margin > game.full_game_spread) result = 'fav_cover';
    else if (margin < game.full_game_spread) result = 'dog_cover';
    else result = 'push';
    
    db.prepare('UPDATE games SET result = ? WHERE id = ?').run(result, gameId);
    updateTeamATS(game, result, false);
  }
  
  // H1 ATS result
  if (game.h1_spread && game.h1_favorite && game.home_score_h1 !== null) {
    const favScore = game.home_team === game.h1_favorite ? game.home_score_h1 : game.away_score_h1;
    const dogScore = game.home_team === game.h1_favorite ? game.away_score_h1 : game.home_score_h1;
    const margin = favScore - dogScore;
    
    let h1Result;
    if (margin > game.h1_spread) h1Result = 'fav_cover';
    else if (margin < game.h1_spread) h1Result = 'dog_cover';
    else h1Result = 'push';
    
    db.prepare('UPDATE games SET h1_result = ? WHERE id = ?').run(h1Result, gameId);
    updateTeamATS(game, h1Result, true);
    checkStreaks();
  }
}

function updateTeamATS(game, result, isH1) {
  const teams = [game.home_team, game.away_team];
  const favorite = isH1 ? game.h1_favorite : game.full_game_favorite;
  
  for (const team of teams) {
    const isFav = team === favorite;
    const covered = (isFav && result === 'fav_cover') || (!isFav && result === 'dog_cover');
    const pushed = result === 'push';
    
    const stats = db.prepare('SELECT * FROM team_stats WHERE team = ?').get(team);
    if (!stats) continue;
    
    if (isH1) {
      let newStreak = stats.h1_streak || 0;
      let streakType = stats.h1_streak_type || 'none';
      
      if (pushed) {
        newStreak = 0;
        streakType = 'none';
      } else if (covered) {
        newStreak = streakType === 'win' ? newStreak + 1 : 1;
        streakType = 'win';
      } else {
        newStreak = streakType === 'loss' ? newStreak + 1 : 1;
        streakType = 'loss';
      }
      
      db.prepare(`
        UPDATE team_stats SET
          h1_ats_wins = h1_ats_wins + ?,
          h1_ats_losses = h1_ats_losses + ?,
          h1_ats_pushes = h1_ats_pushes + ?,
          h1_streak = ?,
          h1_streak_type = ?,
          updated_at = datetime('now')
        WHERE team = ?
      `).run(
        covered ? 1 : 0,
        (!covered && !pushed) ? 1 : 0,
        pushed ? 1 : 0,
        newStreak,
        streakType,
        team
      );
    } else {
      db.prepare(`
        UPDATE team_stats SET
          ats_wins = ats_wins + ?,
          ats_losses = ats_losses + ?,
          ats_pushes = ats_pushes + ?,
          updated_at = datetime('now')
        WHERE team = ?
      `).run(
        covered ? 1 : 0,
        (!covered && !pushed) ? 1 : 0,
        pushed ? 1 : 0,
        team
      );
    }
  }
}

// ─── DASHBOARD SUMMARY ────────────────────────────────────────────
app.get('/api/dashboard', authMiddleware, (req, res) => {
  const todayGames = db.prepare(`
    SELECT * FROM games WHERE date(game_date) = date('now', 'localtime') ORDER BY game_date ASC
  `).all();
  
  const teamStats = db.prepare('SELECT * FROM team_stats ORDER BY team ASC').all();
  
  const recentPicks = db.prepare(`
    SELECT p.*, g.home_team, g.away_team, g.game_date
    FROM picks p JOIN games g ON p.game_id = g.id
    ORDER BY g.game_date DESC LIMIT 20
  `).all();
  
  const pickRecord = db.prepare(`
    SELECT 
      COUNT(CASE WHEN result = 'win' THEN 1 END) as wins,
      COUNT(CASE WHEN result = 'loss' THEN 1 END) as losses,
      COUNT(CASE WHEN result = 'push' THEN 1 END) as pushes,
      COUNT(CASE WHEN result = 'pending' THEN 1 END) as pending
    FROM picks
  `).get();
  
  const streaks = db.prepare(`
    SELECT * FROM team_stats WHERE h1_streak >= 3 ORDER BY h1_streak DESC
  `).all();
  
  res.json({ todayGames, teamStats, recentPicks, pickRecord, streaks });
});

// ─── CRON: Refresh odds every 2 hours ─────────────────────────────
cron.schedule('0 */2 * * *', async () => {
  console.log('Auto-refreshing NBA odds...');
  try {
    const oddsData = await getNBAGames();
    const parsed = parseSpread(oddsData);
    // Update spreads
    const update = db.prepare(`
      UPDATE games SET full_game_spread = ?, full_game_favorite = ?, updated_at = datetime('now') WHERE id = ?
    `);
    parsed.forEach(g => update.run(g.full_game_spread, g.full_game_favorite, g.id));
    console.log(`Refreshed ${parsed.length} games`);
  } catch (err) {
    console.error('Cron error:', err.message);
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`TeeJayStakes server running on port ${PORT}`));
