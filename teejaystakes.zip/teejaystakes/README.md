# TeeJayStakes — NBA Spread Tracker

## First-Time Setup

### Step 1 — Get Your Free Odds API Key
1. Go to https://the-odds-api.com
2. Click "Get API Key" (free, 500 requests/month)
3. Copy your key

### Step 2 — Get Your Gmail App Password (for email alerts)
1. Go to your Google Account → Security
2. Enable 2-Step Verification if not already on
3. Search "App Passwords" → Create one for "Mail"
4. Copy the 16-character password

### Step 3 — Configure Your .env File
Open `server/.env` and fill in:
```
ODDS_API_KEY=your_key_from_step_1
EMAIL_USER=yourgmail@gmail.com
EMAIL_PASS=your_16_char_app_password
ALERT_EMAIL=where_to_send_alerts@gmail.com
```
The SITE_PASSWORD is already set to 2014437054

### Step 4 — Install Dependencies

Open two terminal windows.

**Terminal 1 (Server):**
```
cd teejaystakes/server
npm install
npm start
```

**Terminal 2 (Client):**
```
cd teejaystakes/client
npm install
npm start
```

### Step 5 — Open the App
Go to: http://localhost:3000
Password: 2014437054

---

## How to Use

**Dashboard**
- Click "Refresh Odds" to pull today's NBA games and spreads
- See your pick record at a glance
- See active streaks for all 8 tracked teams
- Red banner alert if any team is on a 3+ game H1 ATS streak

**Games**
- Games auto-load from the Odds API when you refresh
- Add games manually if needed (for early lines not yet on the API)
- Enter halftime and final scores by clicking the score boxes
- Click "+ Pick" on any game to log your pick before tip

**My Picks**
- Full history of all your picks
- Filter by win/loss/push/pending
- See your overall ATS record and win %

**Teams**
- Full ATS breakdown for all 8 tracked teams
- Click "Detail" on Warriors/Lakers/Knicks to see last 10 games

---

## Tracked Teams
**Main (detailed view):** Warriors, Lakers, Knicks
**Secondary:** Bucks, Spurs, Nuggets, Heat, OKC

---

## Email Alerts Trigger When:
- Any tracked team hits 3+ H1 ATS wins in a row
- Any tracked team hits 3+ H1 ATS losses in a row

Odds auto-refresh every 2 hours when server is running.
